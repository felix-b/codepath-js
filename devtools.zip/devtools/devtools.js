chrome.devtools.panels.create(
  "CodePath",
  null,
  "mainPanel.html",
  null
);
